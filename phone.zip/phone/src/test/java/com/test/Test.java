package com.test;

import com.alibaba.fastjson.JSONObject;

public class Test {
	public static void main(String[] args) {
		int[] a = new int[] {1,2,3,4,5};
		int[] b = {2,3,4,};
		JSONObject jsonObject = new JSONObject();
	    jsonObject.put("a",b);
	    jsonObject.put("ah", a);
	    System.out.println(jsonObject);
	    String resultInfoOuterListStr = jsonObject.toString();
		System.out.println(resultInfoOuterListStr);
	}
}

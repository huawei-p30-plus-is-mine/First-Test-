package com.test;

public class Test1 {
	public static void main(String[] args) {
		String regex = "^[a-zA-Z][a-zA-Z0-9_]{5,15}$";
		String userName = "a4555a";
		System.out.println(userName.matches(regex));
	}
}

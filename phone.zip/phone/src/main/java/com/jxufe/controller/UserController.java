package com.jxufe.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jxufe.model.User;
import com.jxufe.pojo.Result;
import com.jxufe.service.IUserService;
import com.jxufe.util.DataRule;

@Controller
@RequestMapping("/user")
public class UserController {
	@Resource
	private IUserService userService;

	private DataRule dataRule;

	@RequestMapping("/showUser")
	public String toIndex(HttpServletRequest request, Model model) {
		System.out.println("进了controller");
		// int useId = Integer.parseInt(request.getParameter("id"));

		List<User> users = this.userService.getAll();
		model.addAttribute("users", users);
		request.setAttribute("users", users);
		System.out.println(users.size());
		return "showUser";
	}

	public User queryUserByUserName(String userName) {
		System.out.println("进了controller中的selectUserByUserName方法！");
		User user = new User();
		user = this.userService.findUserByUserName(userName);
		return user;
	}

	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public Result query(@RequestParam(value = "user_name", required = true) String userName, @RequestParam(value = "password", required = true) String password,
			HttpServletRequest request, Model model) {
	//	userName = request.getParameter("user_name");
	//	password = request.getParameter("password");
		User user = queryUserByUserName(userName);
		if(user == null) {
			return new Result(-10, "该账号不存在！", null);
		}
		if(!user.getPassword().equals(password)) {
			return new Result(-10, "密码错误", null);
		}
		request.getSession().setAttribute("user", user);
		return new Result(200, "登录成功", user);
	}
	
	@RequestMapping(value = "/test_login", method = RequestMethod.POST)
	@ResponseBody
	public Result test_login(HttpServletRequest request, HttpServletResponse response, Model model) {
		User user = (User) request.getSession().getAttribute("user");
		if(user == null) {
			return new Result(-10, "超时！请重新登录！", null);
		}
		return new Result(200, "获取session中的登录用户成功", user);
	}
	
	
	// 插入一条记录
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	@ResponseBody
	public Result add(@RequestBody(required = false) String userName, @RequestBody(required = false) String password,
			HttpServletRequest request, Model model) {
		dataRule = new DataRule();
		userName = request.getParameter("user_name");
		password = request.getParameter("password");
		System.out.println("userName:" + userName);
		System.out.println("password:" + password);
		if (!dataRule.isCorrect(userName, 0) || !dataRule.isCorrect(password, 1)) {
			System.out.println("账号或密码不符合规范！");
			return new Result(-10, "输入的账号或密码不符合规范！", null);
		}
		
		User user = new User();
		user.setUserName(userName);
		user.setPassword(password);
		if (queryUserByUserName(userName) != null) {
			System.out.println("数据库中已存在该账号！");
			return new Result(-10, "该账号已存在！", null);
		} else {
			try {
				System.out.println("成功了");
				this.userService.addUser(user);
				System.out.println("user.id:" + user.getId());
			} catch (Exception e) {
				return new Result(-10, "系统出错，请稍后再试！", null);// 返回字符串给ajax
			}
		}
		return new Result(200, "注册成功！", null);// 返回字符串给ajax
	}

}
package com.jxufe.util;

public class DataRule {
	public boolean isCorrect(String str, int sign) {
		//正则表达式：用户名：可以包含字母数字和下划线，开头必须为字母，长度为6-16
		String userNameRegex = "^[a-zA-Z][a-zA-Z0-9_]{5,15}$";
		//正则表达式：密码：可以包含字母数字和下划线长度为6-16
		String passwordRegex = "^[a-zA-Z0-9_]{6,16}$";
		
		switch (sign) {
		//sign=0，表示是要判断userName
		case 0:
			if(str.matches(userNameRegex)) {
				return true;
			}
			break;
		case 1:
			if(str.matches(passwordRegex)) {
				return true;
			}
		default:
			break;
		}
		return false;
	}
}

package com.jxufe.pojo;


public class Result {
	private int code;    //返回100表示成功,200表示失败
    private String message;    //返回提示信息
    private Object data;    //用户返回给浏览器的数据
	public Result() {
		super();
	}
	public Result(int code, String message, Object data) {
		super();
		this.code = code;
		this.message = message;
		this.data = data;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
}

package com.jxufe.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jxufe.model.User;

public interface IUserDao {
	 /**
     * 通过userId查询User
     * @author zx
     * @date 2019年04月09日 下午3:59:40
     * @param userId
     * @return
     */
    User selectUserByUserName(String userName);
    
    List<User> selectAll();
    
    int insertUser(User user);
    
}

package com.jxufe.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jxufe.dao.IUserDao;
import com.jxufe.model.User;
import com.jxufe.service.IUserService;

@Service("userService")
public class UserServiceImpl implements IUserService {
	@Resource
	private IUserDao userDao;

	@Override
	public User findUserByUserName(String userName) {
		return this.userDao.selectUserByUserName(userName);
	}

	@Override
	public List<User> getAll() {
		return this.userDao.selectAll();
	}

	@Override
	public int addUser(User user) {
		System.out.println("进了service层的addUser方法");
		System.out.println("user.name:"+user.getUserName());
//		User dbUser = new User();
//		dbUser = this.userDao.selectUserByUserName(user.getUserName());
//		if(dbUser.getUserName().equals(user.getUserName())) {
//			System.out.println("已存在该账号！");
//			return 0;
//		}
		return this.userDao.insertUser(user);
	}

}
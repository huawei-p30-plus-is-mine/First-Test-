package com.jxufe.service;

import java.util.List;

import com.jxufe.model.User;

public interface IUserService {
	public User findUserByUserName(String userName);
	public List<User> getAll();
	public int addUser(User user);
}
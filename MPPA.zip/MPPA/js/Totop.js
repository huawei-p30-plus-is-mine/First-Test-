$(function() {
			$('#list').click(function() {
				$('#thread').toggle();
			})
			$('#top').hide();
			$('#thread').hide();
			$('#list').hide();
			$(function() {
				$(window).scroll(function() {
					if($(window).scrollTop() > 200) {
						$('#top').fadeIn(200);
						$('#list').fadeIn(200);
					} else {
						$('#thread').fadeOut(200);
						$('#top').fadeOut(200);
						$('#list').fadeOut(200);
					}

				});

				$('#top').click(function() {

					$('body,html').animate({
						scrollTop: 0
					}, 200);
					return false;

				})

			})

		})